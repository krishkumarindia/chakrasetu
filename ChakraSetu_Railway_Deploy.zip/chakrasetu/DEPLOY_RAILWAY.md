# ChakraSetu Railway deployment

This package is configured for a **public hackathon demo**, not private data or production users. It enables explicitly marked DEMO_MODE in a production HTTPS environment. Do not use real personal/operational data or keep a universal demo password for real accounts.

1. Push the `chakrasetu` directory to a private GitHub repository (or use Railway CLI).
2. Railway > New Project > Deploy from GitHub repo; the Dockerfile is automatically detected.
3. Add a persistent **Volume** mounted at `/data` to the service. SQLite and uploaded documents live there.
4. Variables: `APP_ENV=production`, `DEMO_MODE=true`, `CHAKRA_DEMO_PASSWORD=Demo1234567890`, `DATABASE_URL=sqlite:////data/chakrasetu.db`, `UPLOAD_DIR=/data/uploads`. The shared password here is public demo-only.
5. Networking > Generate Domain. Set `ALLOWED_ORIGINS=https://YOUR-RAILWAY-DOMAIN` using the generated hostname. Redeploy.
6. Test `https://YOUR-RAILWAY-DOMAIN/api/health`, homepage, login, and role workflows.

Important: this project uses SQLite with SQLite-only PRAGMA hooks, so **do not provision a PostgreSQL database** without further code changes. Run one application replica only.

For Render, a persistent disk is typically a paid feature; without one, SQLite accounts/data/uploads will be lost on redeploy/restart. Railway volume and usage may also require payment.

This file documents manual deployment. No live hosting account is connected or deployed by this package.
