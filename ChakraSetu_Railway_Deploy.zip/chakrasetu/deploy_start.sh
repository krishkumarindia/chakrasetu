#!/bin/sh
set -eu
export DATABASE_URL="${DATABASE_URL:-sqlite:////data/chakrasetu.db}"
export UPLOAD_DIR="${UPLOAD_DIR:-/data/uploads}"
mkdir -p "$UPLOAD_DIR"
if [ "${DEMO_MODE:-false}" = "true" ]; then
  if [ ! -f /data/.demo_initialized ]; then
    : "${CHAKRA_DEMO_PASSWORD:?Set CHAKRA_DEMO_PASSWORD in service environment (12+ chars)}"
    cd /app/backend
    python -m app.auth_bootstrap --demo
    touch /data/.demo_initialized
    cd /app
  fi
fi
exec uvicorn serve:app --host 0.0.0.0 --port "${PORT:-8000}"
