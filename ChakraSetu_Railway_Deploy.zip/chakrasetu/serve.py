"""Single-domain production entrypoint: FastAPI API and built React SPA."""
import os
from pathlib import Path
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from starlette.responses import FileResponse
from starlette.exceptions import HTTPException
from app.main import app as api

class SPAFiles(StaticFiles):
    async def get_response(self, path, scope):
        try:
            return await super().get_response(path, scope)
        except HTTPException as exc:
            if exc.status_code == 404 and scope.get("method") in ("GET", "HEAD") and "." not in Path(path).name:
                return FileResponse(self.directory + "/index.html")
            raise

app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
app.mount("/api", api)
app.mount("/", SPAFiles(directory=str(Path(__file__).parent / "frontend" / "dist"), html=True))
